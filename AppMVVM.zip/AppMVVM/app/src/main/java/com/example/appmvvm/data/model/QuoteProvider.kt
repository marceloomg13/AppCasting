package com.example.appmvvm.data.model

class QuoteProvider {
    companion object {
        var quotes:List<QuoteModel> = emptyList()
    }
}